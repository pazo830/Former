package com.mycompany.mywebapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MywebappApplicationTests {

    @Test
    void contextLoads() {
    }

}
