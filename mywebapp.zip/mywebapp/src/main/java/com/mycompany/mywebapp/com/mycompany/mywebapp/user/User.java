package com.mycompany.mywebapp.com.mycompany.mywebapp.user;
import javax.persistence.*;

@Entity
@Table(name = "users")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
   private Integer id;
    @Column(nullable = false,unique = true,length = 45)
   private String email;
    @Column(length = 8,nullable = false)
   private String Password;
    @Column(length = 45,nullable = false,name="first_name")
  private String Firstname;
    @Column(length = 45,nullable = false,name="last_name")
  private  String Lastname;

}
